document.getElementbyId('weatherform').addEventListeners('submit',function(e) {0-}
